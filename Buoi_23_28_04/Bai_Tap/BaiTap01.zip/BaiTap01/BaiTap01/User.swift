//
//  User.swift
//  BaiTap01
//
//  Created by Ong_Lao_Ngao on 5/1/20.
//  Copyright © 2020 Ong_Lao_Ngao. All rights reserved.
//

import Foundation
struct User{
    var ketQuaHienThi: String
}
